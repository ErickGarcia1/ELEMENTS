1. Erick Garcia
2. This assignment took around 30 mins to complete
3. Figuring out how to do the feedback on the bit register was the most
important part. Understanding the syntax necessary to do that was a big
hump to get past.
