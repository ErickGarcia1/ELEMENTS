1. Erick Garcia

2. This assignment took around 1 hour

3. The biggest aha moments came from understanding how to manipulate the
control inputs. Understanding which instructions load certain registers
and the logic needed to make sure those registers are loaded when
those instructions occur and not loaded otherwise. The biggest issue was
wrapping my head around the logic, but implementing it was relatively
straightforward.
