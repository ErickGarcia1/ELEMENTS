1. Erick Garcia, with syntax assistance from Miles Claver

2. I spent around 10 hours on this project in total

3. This is my first time programming in Rust, so some assistance was needed with figuring out syntax and the idiosyncracies of the language. Eventually, I figure out how certain variables had to be borrowed and how to work with and around the borrow checker, and once I understood that the rest of the project started to flow a little better.

4. Enter the assembler/ directory and execute 'cargo run **asm file**'
