1. Code written by Erick Garcia. Logic Gate Simulator by steven777400 on SourceFourge.net was used to plan out basic blocks like AND, OR, NOT, XOR, MUX, and DMUX. 
2. I spent around 4 hours total on this project, including the time spent planning out gates.
3. It was very useful to understand the relationship between 2way, 4way, and 8way muxes and Dmuxes. This made it such that I didn't need to use a whole bunch of 2ways to create an 8way. Knowing how selects work and the relationship between smaller and higher magnitudes made it far easier.
