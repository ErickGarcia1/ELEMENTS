1. Erick Garcia

2. This assignment took around an hour to complete

3. It took me a bit to understand how to do multiplication using addition.
Initially I thought I would need to do some bit shifting to do
multiplication the way it's done by hand, but that isn't necessary.
It also took time to understand exactly how to color every pixel on the
screen. I initially tried to change the variable that is changing, but that
proved to be too difficult using only two registers, so I decided to set
up a branch that made it black and another that made it white.
