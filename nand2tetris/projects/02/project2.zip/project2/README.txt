1. Written by Erick Garcia

2. This assignment probably took around 3 hours total, including planning and
troubleshooting

3. It took me a while to figure out that in-between wires could not be saparated
into different inputs. However, I also found out that an output can be set in 
chips as single or group of bits, so that fixed the issue I was having. 
